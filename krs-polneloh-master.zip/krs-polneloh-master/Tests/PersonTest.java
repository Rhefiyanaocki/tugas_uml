package Tests;

import Models.Person;

public class PersonTest {
    public static void main(String [] args){
        Person person;
        
//        
        
    }
}
